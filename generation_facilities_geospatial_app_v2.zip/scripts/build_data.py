#!/usr/bin/env python3
"""Build the browser-ready generation data store from active and retired CSV extracts."""
from __future__ import annotations

import argparse
import csv
import json
import math
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


def clean(value: Any) -> str:
    return str(value or "").strip()


def number(value: Any) -> float | None:
    text = clean(value).replace(",", "")
    if not text:
        return None
    try:
        value = float(text)
    except ValueError:
        return None
    return value if math.isfinite(value) else None


def integer(value: Any) -> int | None:
    value = number(value)
    return int(value) if value is not None else None


def mode(values: Iterable[str], fallback: str = "") -> str:
    candidates = [v for v in values if v]
    return Counter(candidates).most_common(1)[0][0] if candidates else fallback


def valid_coordinate(lat: float | None, lon: float | None) -> bool:
    return lat is not None and lon is not None and -90 <= lat <= 90 and -180 <= lon <= 180


class Dictionary:
    def __init__(self) -> None:
        self.values: list[str] = []
        self.indexes: dict[str, int] = {}

    def add(self, value: Any) -> int:
        text = clean(value)
        if text not in self.indexes:
            self.indexes[text] = len(self.values)
            self.values.append(text)
        return self.indexes[text]


def read_rows(path: Path, source: int) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        required = {
            "Entity ID", "Entity Name", "Plant ID", "Plant Name", "Plant State",
            "County", "Sector", "Generator ID", "Nameplate Capacity (MW)",
            "Technology", "Operating Year", "Status", "Latitude", "Longitude",
        }
        missing = required.difference(reader.fieldnames or [])
        if missing:
            raise ValueError(f"{path.name} is missing required columns: {', '.join(sorted(missing))}")
        for row in reader:
            row["__source"] = source
            rows.append(row)
    return rows


def build(active_path: Path, retired_path: Path) -> dict[str, Any]:
    raw_rows = read_rows(active_path, 0) + read_rows(retired_path, 1)
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in raw_rows:
        plant_id = clean(row.get("Plant ID"))
        if not plant_id:
            plant_id = f"missing:{clean(row.get('Plant Name'))}:{clean(row.get('Plant State'))}"
        grouped[plant_id].append(row)

    dictionaries = {name: Dictionary() for name in [
        "entities", "plants", "states", "counties", "sectors", "technologies",
        "statuses", "energySources", "primeMovers",
    ]}

    facilities: list[list[Any]] = []
    generators: list[list[Any]] = []
    quality = Counter()

    for plant_id in sorted(grouped, key=lambda x: (not x.isdigit(), int(x) if x.isdigit() else x)):
        rows = grouped[plant_id]
        entity = mode((clean(r.get("Entity Name")) for r in rows), "Unknown entity")
        plant = mode((clean(r.get("Plant Name")) for r in rows), "Unnamed facility")
        state = mode((clean(r.get("Plant State")).upper() for r in rows), "Unknown")
        county = mode((clean(r.get("County")) for r in rows), "Unknown")
        sector = mode((clean(r.get("Sector")) for r in rows), "Unspecified")

        coordinate_pairs = []
        for row in rows:
            lat = number(row.get("Latitude"))
            lon = number(row.get("Longitude"))
            if valid_coordinate(lat, lon):
                coordinate_pairs.append((round(lat, 6), round(lon, 6)))
            else:
                quality["generatorRowsMissingCoordinates"] += 1
        if coordinate_pairs:
            lat, lon = Counter(coordinate_pairs).most_common(1)[0][0]
        else:
            lat, lon = None, None
            quality["facilitiesMissingCoordinates"] += 1

        generator_start = len(generators)
        facility_index = len(facilities)

        sorted_rows = sorted(
            rows,
            key=lambda r: (
                int(r["__source"]),
                integer(r.get("Operating Year")) or 9999,
                clean(r.get("Generator ID")),
            ),
        )

        for row in sorted_rows:
            nameplate = number(row.get("Nameplate Capacity (MW)"))
            summer = number(row.get("Net Summer Capacity (MW)"))
            winter = number(row.get("Net Winter Capacity (MW)"))
            operating_year = integer(row.get("Operating Year"))
            retirement_year = integer(row.get("Planned Retirement Year"))

            if nameplate is None:
                quality["generatorRowsMissingNameplate"] += 1
            if operating_year is None:
                quality["generatorRowsMissingOperatingYear"] += 1
            if retirement_year is not None and operating_year is not None and retirement_year < operating_year:
                quality["generatorRowsRetirementBeforeOperation"] += 1

            generators.append([
                clean(row.get("Generator ID")),
                nameplate,
                summer,
                winter,
                dictionaries["technologies"].add(row.get("Technology") or "Unknown"),
                dictionaries["energySources"].add(row.get("Energy Source Code")),
                dictionaries["primeMovers"].add(row.get("Prime Mover Code")),
                integer(row.get("Operating Month")),
                operating_year,
                integer(row.get("Planned Retirement Month")),
                retirement_year,
                dictionaries["statuses"].add(row.get("Status")),
                int(row["__source"]),
            ])

        facilities.append([
            plant_id,
            dictionaries["entities"].add(entity),
            dictionaries["plants"].add(plant),
            dictionaries["states"].add(state),
            dictionaries["counties"].add(county),
            dictionaries["sectors"].add(sector),
            lat,
            lon,
            generator_start,
            len(rows),
        ])

    active_rows = sum(1 for row in raw_rows if row["__source"] == 0)
    retired_rows = len(raw_rows) - active_rows
    mapped_facilities = sum(1 for facility in facilities if facility[6] is not None and facility[7] is not None)

    payload = {
        "schemaVersion": 1,
        "metadata": {
            "title": "U.S. Generation Facilities",
            "snapshot": "January 2026",
            "generatedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "sourceFiles": [active_path.name, retired_path.name],
            "facilityCount": len(facilities),
            "mappedFacilityCount": mapped_facilities,
            "generatorCount": len(generators),
            "activeGeneratorCount": active_rows,
            "retiredGeneratorCount": retired_rows,
            "quality": dict(quality),
        },
        "dictionaries": {name: dictionary.values for name, dictionary in dictionaries.items()},
        "facilities": facilities,
        "generators": generators,
    }
    return payload


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--active", type=Path, required=True)
    parser.add_argument("--retired", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    payload = build(args.active, args.retired)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    serialized = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    args.output.write_text(
        "/* Generated file. Run scripts/build_data.py to refresh. */\n"
        "window.GENERATION_DATA=" + serialized + ";\n",
        encoding="utf-8",
    )
    print(json.dumps(payload["metadata"], indent=2))
    print(f"Wrote {args.output} ({args.output.stat().st_size / 1024 / 1024:.2f} MiB)")


if __name__ == "__main__":
    main()
