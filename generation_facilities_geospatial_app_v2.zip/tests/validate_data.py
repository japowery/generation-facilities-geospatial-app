#!/usr/bin/env python3
"""Validate the generated JavaScript data store without a browser."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

PREFIX = "window.GENERATION_DATA="


def load_store(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    start = text.find(PREFIX)
    if start < 0:
        raise ValueError("GENERATION_DATA assignment not found")
    payload = text[start + len(PREFIX):].strip()
    if payload.endswith(";"):
        payload = payload[:-1]
    return json.loads(payload)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("path", nargs="?", type=Path, default=Path("data/generation-data.js"))
    args = parser.parse_args()

    data = load_store(args.path)
    assert data["schemaVersion"] == 1
    metadata = data["metadata"]
    dictionaries = data["dictionaries"]
    facilities = data["facilities"]
    generators = data["generators"]

    assert metadata["facilityCount"] == len(facilities)
    assert metadata["generatorCount"] == len(generators)
    assert metadata["activeGeneratorCount"] + metadata["retiredGeneratorCount"] == len(generators)

    expected_start = 0
    mapped = 0
    active = 0
    retired = 0
    for facility in facilities:
        assert len(facility) == 10
        plant_id, entity, plant, state, county, sector, lat, lon, start, count = facility
        assert plant_id
        assert 0 <= entity < len(dictionaries["entities"])
        assert 0 <= plant < len(dictionaries["plants"])
        assert 0 <= state < len(dictionaries["states"])
        assert 0 <= county < len(dictionaries["counties"])
        assert 0 <= sector < len(dictionaries["sectors"])
        assert start == expected_start
        assert count > 0
        expected_start += count
        if lat is not None or lon is not None:
            assert lat is not None and lon is not None
            assert -90 <= lat <= 90 and -180 <= lon <= 180
            mapped += 1

    assert expected_start == len(generators)
    assert mapped == metadata["mappedFacilityCount"]

    for generator in generators:
        assert len(generator) == 13
        assert 0 <= generator[4] < len(dictionaries["technologies"])
        assert 0 <= generator[5] < len(dictionaries["energySources"])
        assert 0 <= generator[6] < len(dictionaries["primeMovers"])
        assert 0 <= generator[11] < len(dictionaries["statuses"])
        assert generator[12] in (0, 1)
        active += generator[12] == 0
        retired += generator[12] == 1

    assert active == metadata["activeGeneratorCount"]
    assert retired == metadata["retiredGeneratorCount"]

    print(
        f"Validated {len(facilities):,} facilities, {len(generators):,} generator records, "
        f"and {mapped:,} mapped facilities."
    )


if __name__ == "__main__":
    main()
