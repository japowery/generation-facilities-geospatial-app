(() => {
  "use strict";

  const DATA = window.GENERATION_DATA;
  const $ = (id) => document.getElementById(id);
  const app = $("app");
  const loadingScreen = $("loadingScreen");
  const loadingMessage = $("loadingMessage");
  const loadingProgress = $("loadingProgress");
  const fatalError = $("fatalError");
  const fatalErrorMessage = $("fatalErrorMessage");

  const F = Object.freeze({
    ID: 0, ENTITY: 1, NAME: 2, STATE: 3, COUNTY: 4, SECTOR: 5,
    LAT: 6, LON: 7, START: 8, COUNT: 9,
  });
  const G = Object.freeze({
    ID: 0, NAMEPLATE: 1, SUMMER: 2, WINTER: 3, TECH: 4, ENERGY: 5,
    PRIME: 6, OP_MONTH: 7, OP_YEAR: 8, RET_MONTH: 9, RET_YEAR: 10,
    STATUS: 11, SOURCE: 12,
  });

  const sourceLabels = ["Active", "Retired"];
  const markerRenderer = window.L ? L.canvas({ padding: 0.5, tolerance: 5 }) : null;
  const dictionaries = DATA?.dictionaries || {};
  const rawFacilities = DATA?.facilities || [];
  const rawGenerators = DATA?.generators || [];
  const metadata = DATA?.metadata || {};

  let map;
  let lightTiles;
  let darkTiles;
  let activeTiles;
  let markerLayer;
  let heatLayer;
  let facilityModels = [];
  let markers = [];
  let visibleFacilities = [];
  let visibleByIndex = new Map();
  let lastAggregate = null;
  let renderTimer = null;
  let toastTimer = null;
  let currentDetailIndex = null;
  let currentPage = 1;
  let currentTab = "overview";
  let legendExpanded = true;

  const charts = {};
  const controls = {};

  const filters = {
    active: true,
    retired: true,
    search: "",
    technologies: new Set(),
    states: new Set(),
    sectors: new Set(),
    operatingYearMin: 1900,
    operatingYearMax: 2026,
    capacityMin: 0,
    capacityMax: 7000,
    heat: false,
    scaleDots: true,
  };

  const universe = {
    technologies: [],
    states: [],
    sectors: [],
    operatingYearMin: 1900,
    operatingYearMax: 2026,
    capacityMax: 7000,
  };

  const numberFormatter = new Intl.NumberFormat(undefined, { maximumFractionDigits: 0 });
  const oneDecimalFormatter = new Intl.NumberFormat(undefined, { maximumFractionDigits: 1 });
  const compactFormatter = new Intl.NumberFormat(undefined, { notation: "compact", maximumFractionDigits: 1 });

  function setLoading(percent, message) {
    loadingProgress.style.width = `${Math.max(0, Math.min(100, percent))}%`;
    if (message) loadingMessage.textContent = message;
  }

  function fail(message, error) {
    console.error(message, error || "");
    loadingScreen.classList.add("hidden");
    fatalError.hidden = false;
    fatalErrorMessage.textContent = message;
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (character) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;",
    }[character]));
  }

  function normalize(value) {
    return String(value ?? "").trim().toLowerCase().replace(/\s+/g, " ");
  }

  function finite(value) {
    return typeof value === "number" && Number.isFinite(value);
  }

  function fmt(value, decimals = 0) {
    if (!finite(value)) return "—";
    return decimals ? oneDecimalFormatter.format(value) : numberFormatter.format(Math.round(value));
  }

  function fmtMw(value) {
    if (!finite(value)) return "—";
    return `${value >= 10000 ? compactFormatter.format(value) : fmt(value, value < 100 ? 1 : 0)} MW`;
  }

  function fmtDateTime(value) {
    if (!value) return "—";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric" });
  }

  function sumMap(target, source) {
    for (const [key, value] of source) target.set(key, (target.get(key) || 0) + value);
  }

  function topEntries(mapValue, limit = 10) {
    return [...mapValue.entries()].sort((a, b) => b[1] - a[1]).slice(0, limit);
  }

  function hashHue(text) {
    let hash = 2166136261;
    const value = String(text || "Unknown");
    for (let i = 0; i < value.length; i += 1) {
      hash ^= value.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
  }

  function technologyColor(technology) {
    const value = normalize(technology);
    if (value.includes("solar")) return "#f5c451";
    if (value.includes("wind")) return "#43c8d8";
    if (value.includes("hydro") || value.includes("water")) return "#4b91f1";
    if (value.includes("natural gas") || value === "other natural gas") return "#ff9d5c";
    if (value.includes("coal")) return "#8793a2";
    if (value.includes("petroleum") || value.includes("oil")) return "#ef6875";
    if (value.includes("nuclear")) return "#b38cff";
    if (value.includes("batter")) return "#5dd39e";
    if (value.includes("geothermal")) return "#e47bd0";
    if (value.includes("biomass") || value.includes("wood") || value.includes("landfill")) return "#79c267";
    const hue = hashHue(technology) % 360;
    return `hsl(${hue} 62% 58%)`;
  }

  function technologyGroup(name) {
    const value = normalize(name);
    if (["solar", "wind", "hydro", "geothermal", "biomass", "wood", "landfill", "municipal solid waste"].some((token) => value.includes(token))) return "renewables";
    if (["natural gas", "coal", "petroleum", "oil", "other gases"].some((token) => value.includes(token))) return "fossil";
    if (value.includes("nuclear")) return "nuclear";
    if (value.includes("batter") || value.includes("pumped storage")) return "storage";
    return "other";
  }

  function roundCapacityMax(value) {
    if (value <= 100) return Math.ceil(value / 10) * 10;
    if (value <= 1000) return Math.ceil(value / 100) * 100;
    return Math.ceil(value / 500) * 500;
  }


  function storageGet(key) {
    try { return window.localStorage.getItem(key); } catch (_) { return null; }
  }

  function storageSet(key, value) {
    try { window.localStorage.setItem(key, value); } catch (_) { /* storage can be unavailable in hardened or opaque contexts */ }
  }

  function replaceUrl(url) {
    try { history.replaceState(null, "", url); } catch (_) { /* URL state is optional in restricted file contexts */ }
  }

  function showToast(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
  }

  class MultiSelect {
    constructor(element, { label, items, selected, onChange }) {
      this.element = element;
      this.label = label;
      this.items = items;
      this.selected = new Set(selected);
      this.onChange = onChange;
      this.searchTerm = "";
      this.renderShell();
      this.renderOptions();
      this.updateButton();
    }

    renderShell() {
      this.element.innerHTML = `
        <button class="multi-select-button" type="button" aria-haspopup="listbox" aria-expanded="false">
          <span></span>
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 9 5 5 5-5"/></svg>
        </button>
        <div class="multi-select-menu">
          <input class="multi-search" type="search" placeholder="Search ${escapeHtml(this.label.toLowerCase())}…" aria-label="Search ${escapeHtml(this.label.toLowerCase())}">
          <div class="multi-actions"><button type="button" data-action="all">Select all</button><button type="button" data-action="none">Clear</button></div>
          <div class="multi-options" role="listbox" aria-multiselectable="true"></div>
        </div>`;
      this.button = this.element.querySelector(".multi-select-button");
      this.menu = this.element.querySelector(".multi-select-menu");
      this.search = this.element.querySelector(".multi-search");
      this.optionsElement = this.element.querySelector(".multi-options");

      this.button.addEventListener("click", (event) => {
        event.stopPropagation();
        const opening = !this.element.classList.contains("open");
        document.querySelectorAll(".multi-select.open").forEach((node) => {
          if (node !== this.element) node.classList.remove("open");
        });
        this.element.classList.toggle("open", opening);
        this.button.setAttribute("aria-expanded", String(opening));
        if (opening) setTimeout(() => this.search.focus(), 0);
      });

      this.menu.addEventListener("click", (event) => event.stopPropagation());
      this.search.addEventListener("input", () => {
        this.searchTerm = normalize(this.search.value);
        this.renderOptions();
      });
      this.menu.querySelector('[data-action="all"]').addEventListener("click", () => {
        this.selected = new Set(this.items.map((item) => item.value));
        this.changed();
      });
      this.menu.querySelector('[data-action="none"]').addEventListener("click", () => {
        this.selected.clear();
        this.changed();
      });
    }

    renderOptions() {
      const filtered = this.items.filter((item) => normalize(item.label).includes(this.searchTerm));
      if (!filtered.length) {
        this.optionsElement.innerHTML = '<div class="multi-empty">No matching options</div>';
        return;
      }
      this.optionsElement.innerHTML = filtered.map((item) => `
        <label class="multi-option">
          <input type="checkbox" value="${escapeHtml(item.value)}" ${this.selected.has(item.value) ? "checked" : ""}>
          ${item.color ? `<i class="option-dot" style="--option-color:${item.color}"></i>` : ""}
          <span>${escapeHtml(item.label)}</span>
          ${finite(item.count) ? `<small>${fmt(item.count)}</small>` : ""}
        </label>`).join("");
      this.optionsElement.querySelectorAll("input").forEach((input) => {
        input.addEventListener("change", () => {
          if (input.checked) this.selected.add(input.value);
          else this.selected.delete(input.value);
          this.changed(false);
        });
      });
    }

    changed(rebuild = true) {
      if (rebuild) this.renderOptions();
      this.updateButton();
      this.onChange(new Set(this.selected));
    }

    updateButton() {
      const label = this.button.querySelector("span");
      if (this.selected.size === this.items.length) label.textContent = `All ${this.label.toLowerCase()}`;
      else if (this.selected.size === 0) label.textContent = `No ${this.label.toLowerCase()}`;
      else if (this.selected.size === 1) {
        const selectedValue = [...this.selected][0];
        label.textContent = this.items.find((item) => item.value === selectedValue)?.label || selectedValue;
      } else label.textContent = `${this.selected.size} ${this.label.toLowerCase()} selected`;
    }

    setSelected(values, notify = true) {
      this.selected = new Set([...values].filter((value) => this.items.some((item) => item.value === value)));
      this.renderOptions();
      this.updateButton();
      if (notify) this.onChange(new Set(this.selected));
    }

    selectAll(notify = true) {
      this.setSelected(new Set(this.items.map((item) => item.value)), notify);
    }
  }

  class DualRange {
    constructor(element, { min, max, valueMin, valueMax, step = 1, readout, minInput, maxInput, formatter, onChange }) {
      this.element = element;
      this.min = min;
      this.max = max;
      this.step = step;
      this.readout = readout;
      this.minInput = minInput;
      this.maxInput = maxInput;
      this.formatter = formatter;
      this.onChange = onChange;
      this.rangeMin = element.querySelector(".range-min");
      this.rangeMax = element.querySelector(".range-max");
      this.fill = element.querySelector(".range-fill");

      [this.rangeMin, this.rangeMax].forEach((input) => {
        input.min = String(min);
        input.max = String(max);
        input.step = String(step);
      });
      this.minInput.min = String(min);
      this.minInput.max = String(max);
      this.minInput.step = String(step);
      this.maxInput.min = String(min);
      this.maxInput.max = String(max);
      this.maxInput.step = String(step);

      this.rangeMin.addEventListener("input", () => this.handleRange("min"));
      this.rangeMax.addEventListener("input", () => this.handleRange("max"));
      this.minInput.addEventListener("change", () => this.handleNumber("min"));
      this.maxInput.addEventListener("change", () => this.handleNumber("max"));
      this.setValues(valueMin, valueMax, false);
    }

    handleRange(which) {
      let low = Number(this.rangeMin.value);
      let high = Number(this.rangeMax.value);
      if (low > high) {
        if (which === "min") low = high;
        else high = low;
      }
      this.setValues(low, high, true);
    }

    handleNumber(which) {
      let low = Number(this.minInput.value);
      let high = Number(this.maxInput.value);
      if (!Number.isFinite(low)) low = this.valueMin;
      if (!Number.isFinite(high)) high = this.valueMax;
      low = Math.max(this.min, Math.min(this.max, low));
      high = Math.max(this.min, Math.min(this.max, high));
      if (low > high) {
        if (which === "min") low = high;
        else high = low;
      }
      this.setValues(low, high, true);
    }

    setValues(low, high, notify = true) {
      this.valueMin = Math.max(this.min, Math.min(this.max, low));
      this.valueMax = Math.max(this.min, Math.min(this.max, high));
      if (this.valueMin > this.valueMax) [this.valueMin, this.valueMax] = [this.valueMax, this.valueMin];
      this.rangeMin.value = String(this.valueMin);
      this.rangeMax.value = String(this.valueMax);
      this.minInput.value = String(this.valueMin);
      this.maxInput.value = String(this.valueMax);
      const span = this.max - this.min || 1;
      const left = ((this.valueMin - this.min) / span) * 100;
      const right = 100 - ((this.valueMax - this.min) / span) * 100;
      this.fill.style.left = `${left}%`;
      this.fill.style.right = `${right}%`;
      this.readout.textContent = this.formatter(this.valueMin, this.valueMax);
      if (notify) this.onChange(this.valueMin, this.valueMax);
    }
  }

  function prepareModels() {
    const techCounts = new Map();
    const stateCounts = new Map();
    const sectorCounts = new Map();
    let minYear = Infinity;
    let maxYear = -Infinity;
    let maxFacilityCapacity = 0;

    facilityModels = rawFacilities.map((facility, index) => {
      const model = {
        index,
        id: facility[F.ID],
        entity: dictionaries.entities[facility[F.ENTITY]] || "Unknown entity",
        name: dictionaries.plants[facility[F.NAME]] || "Unnamed facility",
        state: dictionaries.states[facility[F.STATE]] || "",
        county: dictionaries.counties[facility[F.COUNTY]] || "",
        sector: dictionaries.sectors[facility[F.SECTOR]] || "Unspecified",
        lat: facility[F.LAT],
        lon: facility[F.LON],
        start: facility[F.START],
        count: facility[F.COUNT],
        totalMw: 0,
        activeMw: 0,
        retiredMw: 0,
        firstYear: Infinity,
        lastYear: -Infinity,
        technologies: new Set(),
      };

      stateCounts.set(model.state, (stateCounts.get(model.state) || 0) + 1);
      sectorCounts.set(model.sector, (sectorCounts.get(model.sector) || 0) + 1);

      for (let position = model.start; position < model.start + model.count; position += 1) {
        const generator = rawGenerators[position];
        const capacity = finite(generator[G.NAMEPLATE]) ? generator[G.NAMEPLATE] : 0;
        const technology = dictionaries.technologies[generator[G.TECH]] || "Unknown";
        const operatingYear = generator[G.OP_YEAR];
        model.totalMw += capacity;
        if (generator[G.SOURCE] === 0) model.activeMw += capacity;
        else model.retiredMw += capacity;
        model.technologies.add(technology);
        techCounts.set(technology, (techCounts.get(technology) || 0) + 1);
        if (finite(operatingYear)) {
          minYear = Math.min(minYear, operatingYear);
          maxYear = Math.max(maxYear, operatingYear);
          model.firstYear = Math.min(model.firstYear, operatingYear);
          model.lastYear = Math.max(model.lastYear, operatingYear);
        }
      }
      maxFacilityCapacity = Math.max(maxFacilityCapacity, model.totalMw);
      model.searchText = normalize([model.id, model.name, model.entity, model.state, model.county, model.sector, ...model.technologies].join(" "));
      return model;
    });

    universe.technologies = [...techCounts.keys()].sort((a, b) => a.localeCompare(b));
    universe.states = [...stateCounts.keys()].filter(Boolean).sort((a, b) => a.localeCompare(b));
    universe.sectors = [...sectorCounts.keys()].filter(Boolean).sort((a, b) => a.localeCompare(b));
    universe.operatingYearMin = Number.isFinite(minYear) ? minYear : 1900;
    universe.operatingYearMax = Number.isFinite(maxYear) ? maxYear : 2026;
    universe.capacityMax = roundCapacityMax(maxFacilityCapacity);

    filters.technologies = new Set(universe.technologies);
    filters.states = new Set(universe.states);
    filters.sectors = new Set(universe.sectors);
    filters.operatingYearMin = universe.operatingYearMin;
    filters.operatingYearMax = universe.operatingYearMax;
    filters.capacityMin = 0;
    filters.capacityMax = universe.capacityMax;

    return { techCounts, stateCounts, sectorCounts };
  }

  function initializeMap() {
    map = L.map("map", {
      zoomControl: false,
      preferCanvas: true,
      minZoom: 3,
      maxZoom: 18,
      worldCopyJump: true,
    }).setView([38.5, -97.5], 4);

    lightTiles = L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
      subdomains: "abcd",
      maxZoom: 20,
      attribution: "&copy; OpenStreetMap contributors &copy; CARTO",
    });
    darkTiles = L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
      subdomains: "abcd",
      maxZoom: 20,
      attribution: "&copy; OpenStreetMap contributors &copy; CARTO",
    });
    activeTiles = document.documentElement.dataset.theme === "light" ? lightTiles : darkTiles;
    activeTiles.addTo(map);

    map.createPane("heatPane");
    map.getPane("heatPane").style.zIndex = 350;
    map.createPane("markerPaneCustom");
    map.getPane("markerPaneCustom").style.zIndex = 450;

    markerLayer = L.layerGroup().addTo(map);
    markers = facilityModels.map((facility) => {
      if (!finite(facility.lat) || !finite(facility.lon)) return null;
      const marker = L.circleMarker([facility.lat, facility.lon], {
        renderer: markerRenderer,
        pane: "markerPaneCustom",
        radius: 4,
        color: "rgba(255,255,255,.72)",
        weight: 1,
        fillColor: "#5ea6ff",
        fillOpacity: 0.82,
      });
      marker._facilityIndex = facility.index;
      marker.bindPopup((layer) => popupHtml(layer._selection), { maxWidth: 300, closeButton: true });
      marker.on("click", () => {
        currentDetailIndex = facility.index;
      });
      return marker;
    });

    map.on("popupopen", (event) => {
      const button = event.popup.getElement()?.querySelector("[data-open-facility]");
      if (button) button.addEventListener("click", () => openFacility(Number(button.dataset.openFacility)));
    });
  }

  function initializeControls(counts) {
    $("datasetLabel").textContent = `${metadata.snapshot || "Bundled snapshot"} · ${fmt(metadata.generatorCount)} generators`;
    $("activeCountBadge").textContent = fmt(metadata.activeGeneratorCount);
    $("retiredCountBadge").textContent = fmt(metadata.retiredGeneratorCount);

    controls.technology = new MultiSelect($("technologyFilter"), {
      label: "Technologies",
      items: universe.technologies.map((value) => ({ value, label: value, color: technologyColor(value), count: counts.techCounts.get(value) || 0 })),
      selected: filters.technologies,
      onChange: (selected) => {
        filters.technologies = selected;
        syncTechnologyGroupButtons();
        scheduleRender(true);
      },
    });
    controls.state = new MultiSelect($("stateFilter"), {
      label: "States",
      items: universe.states.map((value) => ({ value, label: value, count: counts.stateCounts.get(value) || 0 })),
      selected: filters.states,
      onChange: (selected) => {
        filters.states = selected;
        scheduleRender(true);
      },
    });
    controls.sector = new MultiSelect($("sectorFilter"), {
      label: "Sectors",
      items: universe.sectors.map((value) => ({ value, label: value, count: counts.sectorCounts.get(value) || 0 })),
      selected: filters.sectors,
      onChange: (selected) => {
        filters.sectors = selected;
        scheduleRender(true);
      },
    });

    controls.operatingYear = new DualRange($("operatingYearRange"), {
      min: universe.operatingYearMin,
      max: universe.operatingYearMax,
      valueMin: filters.operatingYearMin,
      valueMax: filters.operatingYearMax,
      readout: $("operatingYearReadout"),
      minInput: $("operatingYearMinInput"),
      maxInput: $("operatingYearMaxInput"),
      formatter: (low, high) => `${Math.round(low)}–${Math.round(high)}`,
      onChange: (low, high) => {
        filters.operatingYearMin = low;
        filters.operatingYearMax = high;
        scheduleRender(true);
      },
    });

    controls.capacity = new DualRange($("capacityRange"), {
      min: 0,
      max: universe.capacityMax,
      valueMin: filters.capacityMin,
      valueMax: filters.capacityMax,
      readout: $("capacityReadout"),
      minInput: $("capacityMinInput"),
      maxInput: $("capacityMaxInput"),
      formatter: (low, high) => `${fmt(low)}–${fmt(high)} MW`,
      onChange: (low, high) => {
        filters.capacityMin = low;
        filters.capacityMax = high;
        scheduleRender(true);
      },
    });

    $("globalSearch").addEventListener("input", () => {
      filters.search = normalize($("globalSearch").value);
      scheduleRender(true);
    });

    $("activeStatusBtn").addEventListener("click", () => {
      filters.active = !filters.active;
      if (!filters.active && !filters.retired) filters.retired = true;
      syncStatusButtons();
      scheduleRender(true);
    });
    $("retiredStatusBtn").addEventListener("click", () => {
      filters.retired = !filters.retired;
      if (!filters.active && !filters.retired) filters.active = true;
      syncStatusButtons();
      scheduleRender(true);
    });

    $("technologyClearBtn").addEventListener("click", () => controls.technology.selectAll());
    $("technologyGroups").addEventListener("click", (event) => {
      const button = event.target.closest("[data-tech-group]");
      if (!button) return;
      const group = button.dataset.techGroup;
      const selected = new Set(universe.technologies.filter((technology) => technologyGroup(technology) === group));
      controls.technology.setSelected(selected);
    });

    $("heatToggle").addEventListener("change", () => {
      filters.heat = $("heatToggle").checked;
      scheduleRender(false);
    });
    $("scaleDotsToggle").addEventListener("change", () => {
      filters.scaleDots = $("scaleDotsToggle").checked;
      scheduleRender(false);
    });

    $("resetBtn").addEventListener("click", resetFilters);
    $("homeBtn").addEventListener("click", resetFilters);
    $("fitSelectionBtn").addEventListener("click", fitSelection);
    $("zoomHomeBtn").addEventListener("click", () => map.setView([38.5, -97.5], 4));
    $("basemapBtn").addEventListener("click", toggleBasemap);
    $("exportBtn").addEventListener("click", exportFacilities);
    $("shareBtn").addEventListener("click", copyShareLink);
    $("themeBtn").addEventListener("click", toggleTheme);
    $("detailCloseBtn").addEventListener("click", closeFacility);
    $("legendToggle").addEventListener("click", toggleLegend);

    $("facilitySort").addEventListener("change", () => {
      currentPage = 1;
      renderFacilityList();
    });
    $("previousPageBtn").addEventListener("click", () => {
      currentPage = Math.max(1, currentPage - 1);
      renderFacilityList();
    });
    $("nextPageBtn").addEventListener("click", () => {
      currentPage += 1;
      renderFacilityList();
    });
    $("facilityList").addEventListener("click", (event) => {
      const row = event.target.closest("[data-facility-index]");
      if (row) openFacility(Number(row.dataset.facilityIndex));
    });

    $("overviewTab").addEventListener("click", () => setTab("overview"));
    $("facilitiesTab").addEventListener("click", () => setTab("facilities"));
    $("dataTab").addEventListener("click", () => setTab("data"));

    document.addEventListener("click", () => {
      document.querySelectorAll(".multi-select.open").forEach((element) => {
        element.classList.remove("open");
        element.querySelector(".multi-select-button")?.setAttribute("aria-expanded", "false");
      });
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "/" && !["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) {
        event.preventDefault();
        $("globalSearch").focus();
      }
      if (event.key === "Escape") {
        closeFacility();
        closeMobilePanels();
      }
    });

    initializeMobilePanels();
    populateMetadata();
    syncStatusButtons();
    applyHashState();
  }

  function initializeMobilePanels() {
    $("filtersMobileBtn").addEventListener("click", () => openMobilePanel("filterPanel"));
    $("insightsMobileBtn").addEventListener("click", () => openMobilePanel("insightsPanel"));
    $("mobileScrim").addEventListener("click", closeMobilePanels);
    document.querySelectorAll("[data-close-panel]").forEach((button) => {
      button.addEventListener("click", () => button.closest(".side-panel")?.classList.remove("mobile-open"));
    });
  }

  function openMobilePanel(id) {
    closeMobilePanels();
    $(id).classList.add("mobile-open");
    $("mobileScrim").classList.add("show");
  }

  function closeMobilePanels() {
    document.querySelectorAll(".side-panel.mobile-open").forEach((panel) => panel.classList.remove("mobile-open"));
    $("mobileScrim").classList.remove("show");
  }

  function syncStatusButtons() {
    const activeButton = $("activeStatusBtn");
    const retiredButton = $("retiredStatusBtn");
    activeButton.classList.toggle("active", filters.active);
    retiredButton.classList.toggle("active", filters.retired);
    activeButton.setAttribute("aria-pressed", String(filters.active));
    retiredButton.setAttribute("aria-pressed", String(filters.retired));
    $("statusSummary").textContent = filters.active && filters.retired ? "All generators" : filters.active ? "Active only" : "Retired only";
  }

  function syncTechnologyGroupButtons() {
    $("technologyGroups").querySelectorAll("[data-tech-group]").forEach((button) => {
      const group = button.dataset.techGroup;
      const groupItems = universe.technologies.filter((technology) => technologyGroup(technology) === group);
      const active = groupItems.length > 0 && groupItems.every((technology) => filters.technologies.has(technology)) && filters.technologies.size === groupItems.length;
      button.classList.toggle("active", active);
    });
  }

  function generatorPasses(generator) {
    const source = generator[G.SOURCE];
    if (source === 0 && !filters.active) return false;
    if (source === 1 && !filters.retired) return false;
    const technology = dictionaries.technologies[generator[G.TECH]] || "Unknown";
    if (!filters.technologies.has(technology)) return false;
    const year = generator[G.OP_YEAR];
    if (finite(year)) {
      if (year < filters.operatingYearMin || year > filters.operatingYearMax) return false;
    } else if (filters.operatingYearMin !== universe.operatingYearMin || filters.operatingYearMax !== universe.operatingYearMax) return false;
    return true;
  }

  function aggregateSelection() {
    const aggregate = {
      capacity: 0,
      generatorCount: 0,
      mappedCount: 0,
      entities: new Set(),
      states: new Set(),
      technologyMw: new Map(),
      stateMw: new Map(),
      operatingYearMw: new Map(),
      retirementYearMw: new Map(),
      retirementThrough2035: 0,
      activeGeneratorCount: 0,
      retiredGeneratorCount: 0,
    };
    const results = [];
    const resultMap = new Map();

    for (const facility of facilityModels) {
      if (!filters.states.has(facility.state) || !filters.sectors.has(facility.sector)) continue;
      if (filters.search && !facility.searchText.includes(filters.search)) continue;

      let capacity = 0;
      let activeMw = 0;
      let retiredMw = 0;
      let generatorCount = 0;
      let activeCount = 0;
      let retiredCount = 0;
      let firstYear = Infinity;
      let lastYear = -Infinity;
      let earliestRetirement = Infinity;
      const generatorIndexes = [];
      const technologyMw = new Map();
      const operatingYearMw = new Map();
      const retirementYearMw = new Map();

      for (let position = facility.start; position < facility.start + facility.count; position += 1) {
        const generator = rawGenerators[position];
        if (!generatorPasses(generator)) continue;
        const mw = finite(generator[G.NAMEPLATE]) ? generator[G.NAMEPLATE] : 0;
        const technology = dictionaries.technologies[generator[G.TECH]] || "Unknown";
        const operatingYear = generator[G.OP_YEAR];
        const retirementYear = generator[G.RET_YEAR];
        const source = generator[G.SOURCE];

        capacity += mw;
        generatorCount += 1;
        generatorIndexes.push(position);
        technologyMw.set(technology, (technologyMw.get(technology) || 0) + mw);
        if (source === 0) {
          activeMw += mw;
          activeCount += 1;
          if (finite(retirementYear)) {
            retirementYearMw.set(retirementYear, (retirementYearMw.get(retirementYear) || 0) + mw);
            earliestRetirement = Math.min(earliestRetirement, retirementYear);
          }
        } else {
          retiredMw += mw;
          retiredCount += 1;
        }
        if (finite(operatingYear)) {
          operatingYearMw.set(operatingYear, (operatingYearMw.get(operatingYear) || 0) + mw);
          firstYear = Math.min(firstYear, operatingYear);
          lastYear = Math.max(lastYear, operatingYear);
        }
      }

      if (!generatorCount) continue;
      if (capacity < filters.capacityMin || capacity > filters.capacityMax) continue;

      const dominantTechnology = topEntries(technologyMw, 1)[0]?.[0] || "Unknown";
      const selection = {
        facility,
        capacity,
        activeMw,
        retiredMw,
        generatorCount,
        activeCount,
        retiredCount,
        firstYear: Number.isFinite(firstYear) ? firstYear : null,
        lastYear: Number.isFinite(lastYear) ? lastYear : null,
        earliestRetirement: Number.isFinite(earliestRetirement) ? earliestRetirement : null,
        generatorIndexes,
        technologyMw,
        dominantTechnology,
      };
      results.push(selection);
      resultMap.set(facility.index, selection);

      aggregate.capacity += capacity;
      aggregate.generatorCount += generatorCount;
      aggregate.activeGeneratorCount += activeCount;
      aggregate.retiredGeneratorCount += retiredCount;
      if (finite(facility.lat) && finite(facility.lon)) aggregate.mappedCount += 1;
      aggregate.entities.add(facility.entity);
      aggregate.states.add(facility.state);
      sumMap(aggregate.technologyMw, technologyMw);
      aggregate.stateMw.set(facility.state, (aggregate.stateMw.get(facility.state) || 0) + capacity);
      sumMap(aggregate.operatingYearMw, operatingYearMw);
      sumMap(aggregate.retirementYearMw, retirementYearMw);
      for (const [year, mw] of retirementYearMw) {
        if (year >= 2026 && year <= 2035) aggregate.retirementThrough2035 += mw;
      }
    }

    visibleFacilities = results;
    visibleByIndex = resultMap;
    return aggregate;
  }

  function scheduleRender(resetPage = false) {
    if (resetPage) currentPage = 1;
    clearTimeout(renderTimer);
    renderTimer = setTimeout(render, 110);
  }

  function render() {
    const aggregate = aggregateSelection();
    lastAggregate = aggregate;
    renderMap();
    renderKpis(aggregate);
    renderCharts(aggregate);
    renderFacilityList();
    renderLegend(aggregate);
    syncHashState();
    if (currentDetailIndex !== null) {
      if (visibleByIndex.has(currentDetailIndex)) renderFacilityDetail(visibleByIndex.get(currentDetailIndex));
      else closeFacility();
    }
  }

  function markerRadius(capacity) {
    if (!filters.scaleDots) return 4.2;
    const cap = Math.max(0, Math.min(capacity, 3000));
    return 2.6 + Math.sqrt(cap / 3000) * 13;
  }

  function renderMap() {
    markerLayer.clearLayers();
    const heatPoints = [];
    let heatMax = 1;
    for (const selection of visibleFacilities) heatMax = Math.max(heatMax, selection.capacity);

    for (const selection of visibleFacilities) {
      const facility = selection.facility;
      const marker = markers[facility.index];
      if (!marker) continue;
      const color = technologyColor(selection.dominantTechnology);
      const outline = selection.activeCount && selection.retiredCount ? "#f4f7fb" : selection.retiredCount ? "#ff9d5c" : "rgba(255,255,255,.78)";
      marker._selection = selection;
      marker.setRadius(markerRadius(selection.capacity));
      marker.setStyle({ fillColor: color, color: outline, weight: selection.retiredCount && !selection.activeCount ? 1.7 : 1.1, fillOpacity: 0.82 });
      marker.addTo(markerLayer);
      heatPoints.push([facility.lat, facility.lon, Math.log10(selection.capacity + 1) / Math.log10(heatMax + 1)]);
    }

    if (filters.heat && typeof L.heatLayer === "function") {
      if (!heatLayer) {
        heatLayer = L.heatLayer(heatPoints, { pane: "heatPane", radius: 25, blur: 19, maxZoom: 10 }).addTo(map);
      } else {
        heatLayer.setLatLngs(heatPoints);
        if (!map.hasLayer(heatLayer)) heatLayer.addTo(map);
      }
    } else if (heatLayer && map.hasLayer(heatLayer)) {
      map.removeLayer(heatLayer);
    }
  }

  function popupHtml(selection) {
    if (!selection) return "";
    const { facility } = selection;
    return `<div class="map-popup">
      <h3>${escapeHtml(facility.name)}</h3>
      <p>${escapeHtml(facility.entity)} · ${escapeHtml(facility.state || "State unavailable")}</p>
      <div class="popup-stats">
        <div class="popup-stat"><span>Visible capacity</span><strong>${fmtMw(selection.capacity)}</strong></div>
        <div class="popup-stat"><span>Generators</span><strong>${fmt(selection.generatorCount)}</strong></div>
        <div class="popup-stat"><span>Technology</span><strong>${escapeHtml(selection.dominantTechnology)}</strong></div>
        <div class="popup-stat"><span>Operating years</span><strong>${selection.firstYear ? `${selection.firstYear}–${selection.lastYear}` : "—"}</strong></div>
      </div>
      <button class="popup-button" type="button" data-open-facility="${facility.index}">Open facility profile</button>
    </div>`;
  }

  function renderKpis(aggregate) {
    $("totalCapacityKpi").textContent = fmtMw(aggregate.capacity);
    $("facilityCountKpi").textContent = fmt(visibleFacilities.length);
    $("generatorCountKpi").textContent = fmt(aggregate.generatorCount);
    $("entityCountKpi").textContent = fmt(aggregate.entities.size);
    $("mappedContext").textContent = `${fmt(aggregate.mappedCount)} mapped`;
    $("statusContext").textContent = `${fmt(aggregate.activeGeneratorCount)} active · ${fmt(aggregate.retiredGeneratorCount)} retired`;
    $("stateCountContext").textContent = `${fmt(aggregate.states.size)} states / territories`;
    $("retirementOutlookKpi").textContent = fmtMw(aggregate.retirementThrough2035);
    $("capacityContext").textContent = visibleFacilities.length ? `${fmt(visibleFacilities.length)} facilities in current selection` : "No facilities match the current filters";
  }

  function chartTheme() {
    const style = getComputedStyle(document.documentElement);
    return {
      text: style.getPropertyValue("--muted").trim(),
      grid: style.getPropertyValue("--border").trim(),
      accent: style.getPropertyValue("--accent").trim(),
      cyan: style.getPropertyValue("--cyan").trim(),
      orange: style.getPropertyValue("--orange").trim(),
    };
  }

  function baseChartOptions({ horizontal = false, tooltipSuffix = " MW", onClick = null } = {}) {
    const theme = chartTheme();
    return {
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      indexAxis: horizontal ? "y" : "x",
      interaction: { mode: "nearest", intersect: true },
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: (context) => `${fmt(Number(context.raw), Number(context.raw) < 100 ? 1 : 0)}${tooltipSuffix}` } },
      },
      scales: {
        x: {
          grid: { color: theme.grid },
          ticks: { color: theme.text, font: { size: 9 }, maxTicksLimit: horizontal ? 5 : 8, callback: horizontal ? (value) => compactFormatter.format(Number(value)) : undefined },
          border: { display: false },
        },
        y: {
          grid: { display: !horizontal, color: theme.grid },
          ticks: { color: theme.text, font: { size: 9 }, autoSkip: !horizontal, maxTicksLimit: horizontal ? 12 : 5, callback: horizontal ? undefined : (value) => compactFormatter.format(Number(value)) },
          border: { display: false },
        },
      },
      onClick,
    };
  }

  function ensureCharts() {
    if (charts.technology || typeof Chart === "undefined") return;
    const theme = chartTheme();
    charts.technology = new Chart($("technologyChart"), {
      type: "bar",
      data: { labels: [], datasets: [{ data: [], backgroundColor: [], borderWidth: 0, borderRadius: 4, barThickness: 13 }] },
      options: baseChartOptions({
        horizontal: true,
        onClick: (_, elements) => {
          if (!elements.length) return;
          const technology = charts.technology.data.labels[elements[0].index];
          controls.technology.setSelected(new Set([technology]));
          showToast(`Filtered to ${technology}`);
        },
      }),
    });
    charts.state = new Chart($("stateChart"), {
      type: "bar",
      data: { labels: [], datasets: [{ data: [], backgroundColor: theme.accent, borderWidth: 0, borderRadius: 4, barThickness: 12 }] },
      options: baseChartOptions({
        horizontal: true,
        onClick: (_, elements) => {
          if (!elements.length) return;
          const state = charts.state.data.labels[elements[0].index];
          controls.state.setSelected(new Set([state]));
          showToast(`Filtered to ${state}`);
        },
      }),
    });
    charts.additions = new Chart($("additionsChart"), {
      type: "line",
      data: { labels: [], datasets: [{ data: [], borderColor: theme.cyan, backgroundColor: `${theme.cyan}22`, borderWidth: 2, pointRadius: 0, pointHoverRadius: 3, tension: 0.2, fill: true }] },
      options: baseChartOptions(),
    });
    charts.retirement = new Chart($("retirementChart"), {
      type: "bar",
      data: { labels: [], datasets: [{ data: [], backgroundColor: theme.orange, borderWidth: 0, borderRadius: 3 }] },
      options: baseChartOptions(),
    });
  }

  function renderCharts(aggregate) {
    ensureCharts();
    if (!charts.technology) return;

    const technology = topEntries(aggregate.technologyMw, 11);
    charts.technology.data.labels = technology.map(([name]) => name);
    charts.technology.data.datasets[0].data = technology.map(([, value]) => value);
    charts.technology.data.datasets[0].backgroundColor = technology.map(([name]) => technologyColor(name));
    charts.technology.update("none");

    const states = topEntries(aggregate.stateMw, 10);
    charts.state.data.labels = states.map(([name]) => name);
    charts.state.data.datasets[0].data = states.map(([, value]) => value);
    charts.state.update("none");

    const operatingYears = [...aggregate.operatingYearMw.entries()].sort((a, b) => a[0] - b[0]);
    charts.additions.data.labels = operatingYears.map(([year]) => String(year));
    charts.additions.data.datasets[0].data = operatingYears.map(([, value]) => value);
    charts.additions.update("none");

    const retirementYears = [];
    for (let year = 2026; year <= 2050; year += 1) retirementYears.push([year, aggregate.retirementYearMw.get(year) || 0]);
    charts.retirement.data.labels = retirementYears.map(([year]) => String(year));
    charts.retirement.data.datasets[0].data = retirementYears.map(([, value]) => value);
    charts.retirement.update("none");
  }

  function renderLegend(aggregate) {
    const entries = topEntries(aggregate.technologyMw, 7);
    $("legendContent").innerHTML = entries.length ? entries.map(([technology, mw]) => `
      <div class="legend-row">
        <i class="legend-dot" style="--legend-color:${technologyColor(technology)}"></i>
        <span title="${escapeHtml(technology)}">${escapeHtml(technology)}</span>
        <small>${compactFormatter.format(mw)}</small>
      </div>`).join("") : '<div class="multi-empty">No visible facilities</div>';
  }

  function sortedVisibleFacilities() {
    const result = [...visibleFacilities];
    switch ($("facilitySort").value) {
      case "capacity-asc": result.sort((a, b) => a.capacity - b.capacity); break;
      case "name-asc": result.sort((a, b) => a.facility.name.localeCompare(b.facility.name)); break;
      case "year-desc": result.sort((a, b) => (b.lastYear || 0) - (a.lastYear || 0)); break;
      case "year-asc": result.sort((a, b) => (a.firstYear || 9999) - (b.firstYear || 9999)); break;
      default: result.sort((a, b) => b.capacity - a.capacity);
    }
    return result;
  }

  function renderFacilityList() {
    const pageSize = 25;
    const sorted = sortedVisibleFacilities();
    const pageCount = Math.max(1, Math.ceil(sorted.length / pageSize));
    currentPage = Math.min(currentPage, pageCount);
    const page = sorted.slice((currentPage - 1) * pageSize, currentPage * pageSize);
    $("facilityListCount").textContent = `${fmt(sorted.length)} facilities`;
    $("pageLabel").textContent = `Page ${currentPage} of ${pageCount}`;
    $("previousPageBtn").disabled = currentPage <= 1;
    $("nextPageBtn").disabled = currentPage >= pageCount;
    $("facilityList").innerHTML = page.length ? page.map((selection) => {
      const { facility } = selection;
      const status = selection.activeCount && selection.retiredCount ? "Mixed history" : selection.activeCount ? "Active" : "Retired";
      return `<article class="facility-row" data-facility-index="${facility.index}" tabindex="0">
        <h3>${escapeHtml(facility.name)}</h3>
        <strong class="facility-mw">${fmtMw(selection.capacity)}</strong>
        <p>${escapeHtml(facility.entity)} · ${escapeHtml(facility.state)} · ${escapeHtml(selection.dominantTechnology)}</p>
        <div class="row-meta"><span class="tiny-tag">${fmt(selection.generatorCount)} gen.</span><span class="tiny-tag">${status}</span></div>
      </article>`;
    }).join("") : '<div class="multi-empty">No facilities match the current filters.</div>';
    $("facilityList").querySelectorAll("[tabindex]").forEach((row) => row.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") openFacility(Number(row.dataset.facilityIndex));
    }));
  }

  function setTab(tab) {
    currentTab = tab;
    const configuration = {
      overview: ["overviewTab", "overviewView"],
      facilities: ["facilitiesTab", "facilitiesView"],
      data: ["dataTab", "dataView"],
    };
    Object.entries(configuration).forEach(([key, [tabId, viewId]]) => {
      const active = key === tab;
      $(tabId).classList.toggle("active", active);
      $(tabId).setAttribute("aria-selected", String(active));
      $(viewId).classList.toggle("active", active);
      $(viewId).hidden = !active;
    });
    if (tab === "overview") setTimeout(() => Object.values(charts).forEach((chart) => chart?.resize()), 0);
    syncHashState();
  }

  function openFacility(index) {
    const selection = visibleByIndex.get(index);
    if (!selection) return;
    currentDetailIndex = index;
    renderFacilityDetail(selection);
    $("detailDrawer").classList.add("open");
    $("detailDrawer").setAttribute("aria-hidden", "false");
    if (finite(selection.facility.lat) && finite(selection.facility.lon)) map.panTo([selection.facility.lat, selection.facility.lon], { animate: true });
    closeMobilePanels();
  }

  function closeFacility() {
    currentDetailIndex = null;
    $("detailDrawer").classList.remove("open");
    $("detailDrawer").setAttribute("aria-hidden", "true");
  }

  function detailGeneratorRows(selection) {
    return selection.generatorIndexes.map((position) => {
      const generator = rawGenerators[position];
      return {
        id: generator[G.ID] || "—",
        nameplate: generator[G.NAMEPLATE],
        summer: generator[G.SUMMER],
        winter: generator[G.WINTER],
        technology: dictionaries.technologies[generator[G.TECH]] || "Unknown",
        energy: dictionaries.energySources[generator[G.ENERGY]] || "—",
        prime: dictionaries.primeMovers[generator[G.PRIME]] || "—",
        operatingYear: generator[G.OP_YEAR],
        retirementYear: generator[G.RET_YEAR],
        status: dictionaries.statuses[generator[G.STATUS]] || sourceLabels[generator[G.SOURCE]],
        source: generator[G.SOURCE],
      };
    }).sort((a, b) => (b.nameplate || 0) - (a.nameplate || 0));
  }

  function renderFacilityDetail(selection) {
    const { facility } = selection;
    const generators = detailGeneratorRows(selection);
    const technologies = topEntries(selection.technologyMw, 20);
    const mapsUrl = finite(facility.lat) && finite(facility.lon)
      ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${facility.lat},${facility.lon}`)}`
      : null;
    $("detailContent").innerHTML = `
      <header class="detail-header">
        <p class="eyebrow">Plant ID ${escapeHtml(facility.id)}</p>
        <h2>${escapeHtml(facility.name)}</h2>
        <p>${escapeHtml(facility.entity)} · ${escapeHtml(facility.county ? `${facility.county} County, ` : "")}${escapeHtml(facility.state)} · ${escapeHtml(facility.sector)}</p>
        <div class="detail-actions">
          ${mapsUrl ? `<a href="${mapsUrl}" target="_blank" rel="noopener">Open in Google Maps</a>` : ""}
          <button type="button" data-copy-plant="${escapeHtml(facility.id)}">Copy plant ID</button>
          <button type="button" data-filter-entity="${escapeHtml(facility.entity)}">Filter to entity</button>
        </div>
      </header>
      <div class="detail-grid">
        <div class="detail-metric"><span>Visible capacity</span><strong>${fmtMw(selection.capacity)}</strong></div>
        <div class="detail-metric"><span>Generators</span><strong>${fmt(selection.generatorCount)}</strong></div>
        <div class="detail-metric"><span>Operating years</span><strong>${selection.firstYear ? `${selection.firstYear}–${selection.lastYear}` : "—"}</strong></div>
        <div class="detail-metric"><span>Earliest retirement</span><strong>${selection.earliestRetirement || "—"}</strong></div>
      </div>
      <section class="detail-section">
        <h3>Technology mix</h3>
        <div class="tech-pills">${technologies.map(([technology, mw]) => `<span class="tech-pill"><i style="--tech-color:${technologyColor(technology)}"></i>${escapeHtml(technology)} · ${fmtMw(mw)}</span>`).join("")}</div>
      </section>
      <section class="detail-section">
        <h3>Generators in current selection (${fmt(generators.length)} of ${fmt(facility.count)})</h3>
        <div class="generator-table-wrap">
          <table class="generator-table">
            <thead><tr><th>ID</th><th>Status</th><th>Technology</th><th class="number">MW</th><th class="number">Summer</th><th class="number">Winter</th><th>Online</th><th>Retirement</th><th>Fuel</th><th>Prime mover</th></tr></thead>
            <tbody>${generators.map((generator) => `<tr>
              <td>${escapeHtml(generator.id)}</td>
              <td><span class="status-badge" style="--status-color:${generator.source === 0 ? "var(--green)" : "var(--orange)"}" title="${escapeHtml(generator.status)}">${sourceLabels[generator.source]}</span></td>
              <td>${escapeHtml(generator.technology)}</td>
              <td class="number">${fmt(generator.nameplate, 1)}</td>
              <td class="number">${fmt(generator.summer, 1)}</td>
              <td class="number">${fmt(generator.winter, 1)}</td>
              <td>${generator.operatingYear || "—"}</td>
              <td>${generator.retirementYear || "—"}</td>
              <td>${escapeHtml(generator.energy)}</td>
              <td>${escapeHtml(generator.prime)}</td>
            </tr>`).join("")}</tbody>
          </table>
        </div>
      </section>`;

    $("detailContent").querySelector("[data-copy-plant]")?.addEventListener("click", async (event) => {
      await copyText(event.currentTarget.dataset.copyPlant);
      showToast("Plant ID copied");
    });
    $("detailContent").querySelector("[data-filter-entity]")?.addEventListener("click", (event) => {
      $("globalSearch").value = event.currentTarget.dataset.filterEntity;
      filters.search = normalize(event.currentTarget.dataset.filterEntity);
      closeFacility();
      scheduleRender(true);
      showToast("Filtered to entity");
    });
  }

  function fitSelection() {
    const coordinates = visibleFacilities
      .filter((selection) => finite(selection.facility.lat) && finite(selection.facility.lon))
      .map((selection) => [selection.facility.lat, selection.facility.lon]);
    if (!coordinates.length) {
      showToast("No mapped facilities in the current selection");
      return;
    }
    if (coordinates.length > 7000 && filters.states.size === universe.states.length) {
      map.setView([38.5, -97.5], 4);
      return;
    }
    map.fitBounds(L.latLngBounds(coordinates), { padding: [45, 45], maxZoom: 9 });
  }

  function resetFilters() {
    filters.active = true;
    filters.retired = true;
    filters.search = "";
    $("globalSearch").value = "";
    controls.technology.selectAll(false);
    controls.state.selectAll(false);
    controls.sector.selectAll(false);
    filters.technologies = new Set(universe.technologies);
    filters.states = new Set(universe.states);
    filters.sectors = new Set(universe.sectors);
    controls.operatingYear.setValues(universe.operatingYearMin, universe.operatingYearMax, false);
    controls.capacity.setValues(0, universe.capacityMax, false);
    filters.operatingYearMin = universe.operatingYearMin;
    filters.operatingYearMax = universe.operatingYearMax;
    filters.capacityMin = 0;
    filters.capacityMax = universe.capacityMax;
    filters.heat = false;
    filters.scaleDots = true;
    $("heatToggle").checked = false;
    $("scaleDotsToggle").checked = true;
    currentPage = 1;
    syncStatusButtons();
    syncTechnologyGroupButtons();
    closeFacility();
    map.setView([38.5, -97.5], 4);
    replaceUrl(`${location.pathname}${location.search}`);
    render();
    showToast("Filters reset");
  }

  function toggleBasemap() {
    const next = activeTiles === darkTiles ? lightTiles : darkTiles;
    map.removeLayer(activeTiles);
    next.addTo(map);
    activeTiles = next;
    showToast(next === darkTiles ? "Dark basemap" : "Light basemap");
  }

  function toggleTheme() {
    const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    storageSet("generation-intelligence-theme", next);
    document.querySelector('meta[name="theme-color"]').setAttribute("content", next === "dark" ? "#09111f" : "#edf2f7");
    const desiredTiles = next === "dark" ? darkTiles : lightTiles;
    if (activeTiles !== desiredTiles) {
      map.removeLayer(activeTiles);
      desiredTiles.addTo(map);
      activeTiles = desiredTiles;
    }
    destroyCharts();
    renderCharts(lastAggregate || aggregateSelection());
  }

  function destroyCharts() {
    Object.keys(charts).forEach((key) => {
      charts[key]?.destroy();
      charts[key] = null;
    });
  }

  function toggleLegend() {
    legendExpanded = !legendExpanded;
    $("legendContent").style.display = legendExpanded ? "grid" : "none";
    $("legendToggle").setAttribute("aria-expanded", String(legendExpanded));
    $("legendToggle").lastElementChild.textContent = legendExpanded ? "−" : "+";
  }

  function csvEscape(value) {
    const text = String(value ?? "");
    return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  }

  function exportFacilities() {
    if (!visibleFacilities.length) {
      showToast("No facilities to export");
      return;
    }
    const headers = [
      "Plant ID", "Facility Name", "Entity Name", "State", "County", "Sector",
      "Visible Nameplate MW", "Active MW", "Retired MW", "Visible Generators",
      "Technologies", "First Operating Year", "Latest Operating Year",
      "Earliest Reported Retirement Year", "Latitude", "Longitude",
    ];
    const rows = sortedVisibleFacilities().map((selection) => {
      const { facility } = selection;
      return [
        facility.id, facility.name, facility.entity, facility.state, facility.county, facility.sector,
        selection.capacity.toFixed(1), selection.activeMw.toFixed(1), selection.retiredMw.toFixed(1), selection.generatorCount,
        [...selection.technologyMw.keys()].join("; "), selection.firstYear || "", selection.lastYear || "",
        selection.earliestRetirement || "", facility.lat ?? "", facility.lon ?? "",
      ];
    });
    const csv = [headers, ...rows].map((row) => row.map(csvEscape).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "us-generation-facilities-filtered.csv";
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    showToast(`${fmt(rows.length)} facilities exported`);
  }

  async function copyText(text) {
    if (navigator.clipboard?.writeText) return navigator.clipboard.writeText(text);
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
  }

  async function copyShareLink() {
    syncHashState();
    await copyText(location.href);
    showToast("Share link copied");
  }

  function setFromHashSet(params, key, universeValues) {
    if (!params.has(key)) return new Set(universeValues);
    const values = params.get(key).split("|").map(decodeURIComponent).filter((value) => universeValues.includes(value));
    return new Set(values);
  }

  function applyHashState() {
    if (!location.hash || location.hash.length < 2) return;
    const params = new URLSearchParams(location.hash.slice(1));
    filters.active = params.get("active") !== "0";
    filters.retired = params.get("retired") !== "0";
    if (!filters.active && !filters.retired) filters.active = true;
    filters.search = normalize(params.get("q") || "");
    $("globalSearch").value = params.get("q") || "";
    filters.technologies = setFromHashSet(params, "tech", universe.technologies);
    filters.states = setFromHashSet(params, "state", universe.states);
    filters.sectors = setFromHashSet(params, "sector", universe.sectors);
    controls.technology.setSelected(filters.technologies, false);
    controls.state.setSelected(filters.states, false);
    controls.sector.setSelected(filters.sectors, false);

    const operating = (params.get("year") || "").split("-").map(Number);
    if (operating.length === 2 && operating.every(Number.isFinite)) {
      filters.operatingYearMin = Math.max(universe.operatingYearMin, operating[0]);
      filters.operatingYearMax = Math.min(universe.operatingYearMax, operating[1]);
      controls.operatingYear.setValues(filters.operatingYearMin, filters.operatingYearMax, false);
    }
    const capacity = (params.get("mw") || "").split("-").map(Number);
    if (capacity.length === 2 && capacity.every(Number.isFinite)) {
      filters.capacityMin = Math.max(0, capacity[0]);
      filters.capacityMax = Math.min(universe.capacityMax, capacity[1]);
      controls.capacity.setValues(filters.capacityMin, filters.capacityMax, false);
    }
    filters.heat = params.get("heat") === "1";
    filters.scaleDots = params.get("scale") !== "0";
    $("heatToggle").checked = filters.heat;
    $("scaleDotsToggle").checked = filters.scaleDots;
    syncStatusButtons();
    syncTechnologyGroupButtons();
    const tab = params.get("tab");
    if (["overview", "facilities", "data"].includes(tab)) setTab(tab);
  }

  function syncHashState() {
    const params = new URLSearchParams();
    if (!filters.active) params.set("active", "0");
    if (!filters.retired) params.set("retired", "0");
    if (filters.search) params.set("q", $("globalSearch").value.trim());
    if (filters.technologies.size !== universe.technologies.length) params.set("tech", [...filters.technologies].map(encodeURIComponent).join("|"));
    if (filters.states.size !== universe.states.length) params.set("state", [...filters.states].map(encodeURIComponent).join("|"));
    if (filters.sectors.size !== universe.sectors.length) params.set("sector", [...filters.sectors].map(encodeURIComponent).join("|"));
    if (filters.operatingYearMin !== universe.operatingYearMin || filters.operatingYearMax !== universe.operatingYearMax) params.set("year", `${Math.round(filters.operatingYearMin)}-${Math.round(filters.operatingYearMax)}`);
    if (filters.capacityMin !== 0 || filters.capacityMax !== universe.capacityMax) params.set("mw", `${Math.round(filters.capacityMin)}-${Math.round(filters.capacityMax)}`);
    if (filters.heat) params.set("heat", "1");
    if (!filters.scaleDots) params.set("scale", "0");
    if (currentTab !== "overview") params.set("tab", currentTab);
    const hash = params.toString();
    const next = `${location.pathname}${location.search}${hash ? `#${hash}` : ""}`;
    replaceUrl(next);
  }

  function populateMetadata() {
    $("dataSnapshotTitle").textContent = `${metadata.snapshot || "Bundled"} snapshot`;
    $("metadataFacilities").textContent = fmt(metadata.facilityCount);
    $("metadataGenerators").textContent = fmt(metadata.generatorCount);
    $("metadataMapped").textContent = `${fmt(metadata.mappedFacilityCount)} (${((metadata.mappedFacilityCount / metadata.facilityCount) * 100).toFixed(1)}%)`;
    $("metadataGenerated").textContent = fmtDateTime(metadata.generatedAt);
    const qualityLabels = {
      generatorRowsMissingCoordinates: "Generator rows missing valid coordinates",
      facilitiesMissingCoordinates: "Facilities unavailable on the map",
      generatorRowsMissingNameplate: "Generator rows missing nameplate capacity",
      generatorRowsMissingOperatingYear: "Generator rows missing operating year",
      generatorRowsRetirementBeforeOperation: "Retirement year before operating year",
    };
    const quality = metadata.quality || {};
    $("qualityList").innerHTML = Object.entries(qualityLabels).map(([key, label]) => `
      <div class="quality-row"><span>${escapeHtml(label)}</span><strong>${fmt(quality[key] || 0)}</strong></div>`).join("");
  }

  async function boot() {
    try {
      if (!DATA || DATA.schemaVersion !== 1) throw new Error("The bundled generation data store is missing or incompatible.");
      if (typeof L === "undefined") throw new Error("Leaflet could not be loaded. Check the network connection or vendor the dependency locally.");
      if (typeof Chart === "undefined") throw new Error("Chart.js could not be loaded. Check the network connection or vendor the dependency locally.");

      const savedTheme = storageGet("generation-intelligence-theme");
      if (["dark", "light"].includes(savedTheme)) document.documentElement.dataset.theme = savedTheme;

      setLoading(18, "Indexing facilities and generator records…");
      await new Promise((resolve) => setTimeout(resolve, 30));
      const counts = prepareModels();

      setLoading(54, "Building the interactive map…");
      await new Promise((resolve) => setTimeout(resolve, 30));
      initializeMap();

      setLoading(76, "Preparing filters and analytics…");
      await new Promise((resolve) => setTimeout(resolve, 30));
      initializeControls(counts);
      render();

      setLoading(100, "Ready");
      await new Promise((resolve) => setTimeout(resolve, 180));
      loadingScreen.classList.add("hidden");
      app.setAttribute("aria-busy", "false");
    } catch (error) {
      fail(error.message || "The application could not start.", error);
    }
  }

  window.GenerationApp = { openFacility };
  boot();
})();
