# Source data staging

The deployed application does not read CSV files from this directory. It reads the generated browser data store at `data/generation-data.js`.

To refresh the snapshot, place the active and retired CSV extracts here or reference them from another location when running `scripts/build_data.py`. Raw source files are not committed by default because redistribution and repository-size requirements may vary.
